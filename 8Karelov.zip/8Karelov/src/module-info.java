/**
 * 
 */
/**
 * @author Kirill
 *
 */
module hw08 {
	requires java.desktop;
}